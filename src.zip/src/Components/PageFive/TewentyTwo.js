import React from 'react'
import one from '../Image/one.jpg'
import congratution from '../Image/congratution.jpg'
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

export default function TewentyTwo() {
  return (
    <> 
    <div>TewentyTwo</div>

    <div className='container' style={{  position: 'relative',
  textAlign: 'center',
  color: 'white'}}>
        <img src={one} alt='BackgroundImaged'/>
        <diV className='centered' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}>

<h1>Congratulations! <CheckCircleIcon/> </h1>
           <img src={congratution} alt='Congratulations!'/>
        
        
        <div>
           <h2>Now you own x% of the 'Ozone Pvt.Limited.'</h2>
           </div>


        </diV>
    </div>


    </>
  )
}
