// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import { useState } from "react";
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ModeCommentIcon from '@mui/icons-material/ModeComment';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { useNavigate } from "react-router-dom";

// grid
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));






export default function Fifteen() {



    // upload img
 
    const [selectedImages, setSelectedImages] = useState([]);
    const onSelectFile = (event) => {
      const selectedFiles = event.target.files;
      const selectedFilesArray = Array.from(selectedFiles);
    
      const imagesArray = selectedFilesArray.map((file) => {
        return URL.createObjectURL(file);
      });
    
      setSelectedImages((previousImages) => previousImages.concat(imagesArray));
    };
    
    // 
    let navigate = useNavigate();
    const HomeBackTo = () => {
      navigate("/SixNavbar");
    };

    let navigateInvest = useNavigate();
    const InvestSixteenTo = () => {
      navigateInvest("/SixteenGraphOne");
    };

  return (
      <> 
      <h1>15</h1>
    <div>Fifteen</div>


    <div>

{/* Logo */}
<div style={{border:'2px solid black', margin:'2%', padding:'1%', backgroundColor:'blueviolet'}}>
<Stack direction="row" spacing={2}>
    <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{height:'100px', width:'100px'}}/>
    <h1>John dept</h1>
    <p>Ozone pvt.ltd</p>
</Stack>
</div>

{/* product decription */}
<div>
<h2>Product's description</h2>
<div style={{border:'2px solid black', borderRadius:'20px'}}>
<p>Lorem Ipsum is simply dummy text of the 
    printing and typesetting industry. Lorem
     Ipsum has been the industry's standard dummy
      text ever since the 1500s, when an unknown 
      printer took a galley of type and scrambled 
      it to make a type specimen book. It has survived not only five 
      centuries, but also the leap into electronic typesetting, remaining
       essentially unchanged. It was popularised in the 1960s with the release 
       of Letraset sheets containing Lorem Ipsum passages, and more recently with . </p>
</div>
</div>

{/* Bussiness Pitch */}
<div>
<h2>Bussiness Pitch</h2>
<div style={{border:'2px solid black', borderRadius:'20px'}}>
<p>Lorem Ipsum is simply dummy text of the 
    printing and typesetting industry. Lorem
     Ipsum has been the industry's standard dummy
      text ever since the 1500s, when an unknown 
      printer took a galley of type and scrambled 
      it to make a type specimen book. It has survived not only five 
      centuries, but also the leap into electronic typesetting, remaining
       essentially unchanged. It was popularised in the 1960s with the release 
       of Letraset sheets containing Lorem Ipsum passages, and more recently with . </p>
</div>
</div>



{/* Product img */}
<div>
<h2>Product Images</h2>

{/* upload img */}
<div>
<section style={{border:'2px solid black', margin:'5%', padding:'3%'}}>
<label>
+ Add Images
<br />
<span>up to 10 images</span>
<input
type="file"
name="images"
onChange={onSelectFile}
multiple
accept="image/png , image/jpeg, image/webp"
/>
</label>
<br />

{selectedImages.length > 0 &&
(selectedImages.length > 10 ? (
<p className="error">
  You can't upload more than 10 images! <br />
  <span>
    please delete <b> {selectedImages.length - 10} </b> of them{" "}
  </span>
</p>
) : (
<button
  className="upload-btn"
  onClick={() => {
    console.log("UPLOAD IMAGES");
  }}
>
  UPLOAD {selectedImages.length} IMAGE
  {selectedImages.length === 1 ? "" : "S"}
</button>
))}

<div className="images">
{selectedImages &&
selectedImages.map((image, index) => {
  return (
    <div key={image} className="image">
      <img src={image} height="200" alt="upload" />
      <button
        onClick={() =>
          setSelectedImages(selectedImages.filter((e) => e !== image))
        }
      >
        delete image
      </button>
      <p>{index + 1}</p>
    </div>
  );
})}
</div>
</section>
</div>
</div>

</div>


{/* TextFields */}
<div>
<Box
component="form"
sx={{
'& > :not(style)': { m: 1, width: '50ch' },
}}
noValidate
autoComplete="off"
>


{/* grid */}
<Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Item>
<TextField id="outlined-basic" label="Company's valuation" variant="outlined" style={{width:'50ch'}}/>

          </Item>
        </Grid>
        <Grid item xs={12}>
          <Item>
<TextField id="outlined-basic" label="Company's sale" variant="outlined" style={{width:'50ch'}}/>

          </Item>
        </Grid>
        <Grid item xs={12}>
          <Item>
<TextField id="outlined-basic" label="Gross margin" variant="outlined" style={{width:'50ch'}}/>

          </Item>
        </Grid>
        <Grid item xs={12}>
          <Item>
<TextField id="outlined-basic" label="Profit in a month" variant="outlined" style={{width:'50ch'}}/>

          </Item>
        </Grid>
        <Grid item xs={12}>
          <Item>
          <TextField id="outlined-basic" label="Profit in a year" variant="outlined" style={{width:'50ch'}}/>
          </Item>
        </Grid>
      </Grid>
    </Box>


</Box>

{/* button */}
<div>
<Stack spacing={2} direction="row">

<Box sx={{ flexGrow: 1 }}>
<Grid container spacing={2}>
<Grid item xs={4}>
<Button variant="text">Like <ThumbUpIcon/> </Button>
</Grid>
<Grid item xs={4}>
<Button variant="contained" onClick={InvestSixteenTo}>Invest</Button>
</Grid>
<Grid item xs={4}>
<Button variant="text">Comment < ModeCommentIcon/> </Button>
</Grid>
<Grid item xs={12}>
<Button variant="text"  onClick={HomeBackTo}> <ArrowBackIosIcon/> Back</Button>
</Grid>
</Grid>
</Box>



{/* <Button variant="text">Like</Button>
<Button variant="contained">Invest</Button>
<Button variant="text">Comment</Button>
<Button variant="text">Back</Button> */}
</Stack>
</div>
</div>





    </>
  )
}
