import React from 'react'
import one from '../Image/one.jpg'
// import LoadingButton from '@mui/lab/LoadingButton';
import '../CSS/Tewenty.css'
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";


export default function Tewenty() {

  let navigateNext = useNavigate();
  const nextTewentyOneTo = () => {
    navigateNext("/TewentyOne");
  };
  let navigateBack = useNavigate();
  const backTewentyTo = () => {
    navigateBack("/Tewenty");
  };

  return (
    <>
    <div>Tewenty</div>



    <div className='container' style={{position: 'relative',
  textAign: 'center',
  color: 'white'}}>
      <img src={one} alt=''/>
      <div className='centered' style={{  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}>
            <div>
            <h1>Confirming your buy!</h1>  

{/* spinner */}
<div className='spinner'>
<div></div>
<div></div>
</div>

{/*  */}

{/* <LoadingButton/> */}
<Stack spacing={2} direction="row">
      <Button variant="text" onClick={backTewentyTo}>Back</Button>
      <Button variant="contained" onClick={nextTewentyOneTo}>Invest</Button>
     
    </Stack>


            </div> 
      </div>
    </div>





    </>
  )
}
