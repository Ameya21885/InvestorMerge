import React from 'react'
import one from '../Image/one.jpg'
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import TextareaAutosize from '@mui/material/TextareaAutosize';
import Button from '@mui/material/Button';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { useNavigate } from "react-router-dom";

export default function Eighteen() {

  let navigateSixteen = useNavigate();
  const backSixteenTo = () => {
    navigateSixteen("/SixteenGraphOne");
  };

  return (
    <> 
    <div>Eighteen</div>
    <div className='container' style={{ position: 'relative',
  textAlign: 'center',
  color: 'white'}}>
      <img src={one} alt='Background Img'/>
      
      <div className='centered' style={{ position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}>
      <h1>Send a negotiable offer!</h1>
     

      <div  style={{border:'2px solid black', margin:'1%', padding:'2%', backgroundColor:'blueviolet', height:'auto', width:600}}> 
    <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
     <h2>Preneurship</h2>
     <br/>
    
    </Stack>
    <TextareaAutosize
      aria-label="minimum height"
      minRows={15}
      placeholder="Minimum 15 rows"
      style={{ width: 500}}
    />
     <Stack spacing={2} direction="row">
      <Button variant="contained">Send</Button>
    </Stack>
  
    </div>

    <Button variant="text" style={{color:'white'}}  onClick={ backSixteenTo}>  <ArrowBackIosNewIcon/> Back</Button>
    

    </div>
    
   

    </div>
   
    </>
  )
}
