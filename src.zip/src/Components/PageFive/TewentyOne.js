import React from 'react'
import one from '../Image/one.jpg'
import GppGoodRoundedIcon from '@mui/icons-material/GppGoodRounded';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";


export default function TewentyOne() {

  let navigateNext = useNavigate();
  const nextTewentyTwoTo = () => {
    navigateNext("/TewentyTwo");
  };

  let navigateNegotitate = useNavigate();
  const negotitateTo = () => {
    navigateNegotitate("/Eighteen");
  };

  let navigateBack = useNavigate();
  const backtewentyTo = () => {
    navigateBack("/Tewenty");
  };

  return (
    <> 
    <div>TewentyOne</div>

    <div className='container' style={{ position: 'relative',
  textAlign: 'center',
  color: 'white'}}>
        <img src={one}  alt='BackgroundImage'/>
        <div className='centered' style={{position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}>
            <div style={{border:'2px solid black', margin:'1%', padding: '20%'}}>
                <GppGoodRoundedIcon/>
                <h1>You can send negotitation message too!</h1>
            </div>

{/* button */}
    <Stack spacing={2} direction="row">
    <Button variant="contained" onClick={backtewentyTo}>Go back!</Button>
      <Button variant="contained" onClick={negotitateTo}>Negotitate</Button>
      <Button variant="contained" onClick={ nextTewentyTwoTo}>Next</Button>
    </Stack>


        </div>
    </div>




    </>
  )
}
