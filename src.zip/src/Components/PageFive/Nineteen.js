import React from 'react'
import one from '../Image/one.jpg'
import verifyingimg from '../Image/verifyingimg.png'
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";


export default function Nineteen() {


  let navigateConform = useNavigate();
  const conformNineteenTo = () => {
    navigateConform("/Tewenty");
  };
  let navigateBackSeventeen = useNavigate();
  const backSeventeenTo = () => {
    navigateBackSeventeen("/SeventeenGraphTwo");
  };


  return (
    <>
    <div>Nineteen</div>

    <div className='container' style={{position: 'relative',
  textAlign: 'center',
  color: 'white'}} >
      <img src={one} alt='BackgroundImg'/>
      <div className='centered' style={{position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)'}}>

<h1>Ready to invest $xyz for p% for the company!</h1>

<img src={verifyingimg} alt='NormalImage'/>

      </div>

      <Stack spacing={2} direction="row">
      <Button variant="contained">Yeah!</Button>
      <Button variant="contained">Might re think!</Button>
      </Stack>
      
      <Button variant="contained" onClick={backSeventeenTo}>Back</Button>
      <Button variant="contained" onClick={conformNineteenTo}>Next</Button>
      

    </div>

    </>
  )
}
