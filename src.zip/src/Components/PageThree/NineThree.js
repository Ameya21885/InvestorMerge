import React from 'react'
import { useEffect, useState } from "react";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';



const renderData = (data) => {
    return (
      <ul>
        {data.map((todo, index) => {
          return(
          <>
          <div style={{border:'2px solid black', margin:'1%', padding:'1%'}}>
          
          <div style={{border:'2px solid black'}}> 
          <img src={todo.thumbnailUrl} alt={todo.url} key={index} height='50px' width='50px' style={{borderRadius:'50px'}}></img>
  <h1>Name</h1>
  </div>
          <h1>{todo.id}</h1> 
          {/* <h3>{todo.albumId}</h3>  */}
          <p>{todo.title}</p> 
          <Stack spacing={2} direction="row">
        <Button variant="text">Like</Button>
        <Button variant="text">DisLike</Button>
        <Button variant="contained">Connect</Button>
      </Stack>
  
          </div>
          </>
          ); 
        })}
      </ul>
    );
  };
  
  




export default function NineOne() {






    const [data, setData] = useState([]);

    const [currentPage, setcurrentPage] = useState(1);
    const [itemsPerPage, setitemsPerPage] = useState(5);
  
    const [pageNumberLimit, setpageNumberLimit] = useState(5);
    const [maxPageNumberLimit, setmaxPageNumberLimit] = useState(5);
    const [minPageNumberLimit, setminPageNumberLimit] = useState(0);
  
    const handleClick = (event) => {
      setcurrentPage(Number(event.target.id));
    };
  
    const pages = [];
    for (let i = 1; i <= Math.ceil(data.length / itemsPerPage); i++) {
      pages.push(i);
    }
  
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = data.slice(indexOfFirstItem, indexOfLastItem);
  
    const renderPageNumbers = pages.map((number) => {
      if (number < maxPageNumberLimit + 1 && number > minPageNumberLimit) {
        return (
          <li
            key={number}
            id={number}
            onClick={handleClick}
            className={currentPage === number ? "active" : null}
          >
            {number}
          </li>
        );
      } else {
        return null;
      }
    });
  
    useEffect(() => {
      fetch("https://jsonplaceholder.typicode.com/photos")
        .then((response) => response.json())
        .then((json) => setData(json));
    }, []);
  
   
  
    
  
    const handleLoadMore = () => {
      setitemsPerPage(itemsPerPage + 5);
    };
  
  
  
  




  return (
    <> 
    <div>NineThree</div>

<div>
<div>
      <h1>Explore</h1>
    </div>
    <div>
    <h1>Todo List</h1> <br />

<div style={{border:'2px solid black'}}> 
{renderData(currentItems)}
</div>

<button onClick={handleLoadMore} className="loadmore">
  Load More
</button>
    </div>
</div>


    </>
  )
}
