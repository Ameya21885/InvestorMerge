// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { useState } from "react";
import "../CSS/Two.css";
import placeholder from "../Image/placeholder2.png";
import { useNavigate } from "react-router-dom";






export default function Seven() {



  const [{ alt, src }, setImg] = useState({
    src: placeholder,
    alt: "Upload an Image"
  });
  var size = {
    heigth: "30px",
    width: "40px"
  };
  const handleImg = (e) => {
    if (e.target.files[0]) {
      setImg({
        src: URL.createObjectURL(e.target.files[0]),
        alt: e.target.files[0].name
      });
    }
  };
  

  // 
  let navigateNext = useNavigate();
  const nextEightTo = () => {
    navigateNext("/Eight");
  };

  let navigateBack = useNavigate();
  const BackSixNavbarTo = () => {
    navigateBack("/SixNavbar");
  };

  
  



  return (
    <>
    <div>Seven</div>
    <div style={{border:'2px solid black', margin:'1%', padding:'3%', backgroundColor:'blue'}}>
    <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" style={{height:100, width:100}}/>
    </Stack>
    </div>
    <h1>Add Details</h1>


{/*  */}
<div>
      <div className="secondpage-container">
        <div className="upper1">
          <div className="logo"></div>
          <div className="heading">
            Welcome to the <span>world</span> of <span>investors</span>
          </div>
        </div>
        <form className="form-container">
          <input type="text" placeholder="Name" required />
          <div className="form__img-input-container">
            <input
              type="file"
              accept=".png,.pdf, .jpg, .jpeg"
              id="f02"
              className="visually-hidden"
            />
            <label for="f02">Verify documents</label>
          </div>
          <div style={{ textAlign: "center" }}> Pan card</div>
         
         
          <input type="text" placeholder="Aadhar Number" required />
    


<div style={{border:'2px solid black', margin:'1%', padding:'6%', borderRadius:'50px'}}>
  <h3>Already added bank</h3>
</div>
<div style={{border:'2px solid black', margin:'1%', padding:'6%', borderRadius:'50px'}}>
  <h3>Already added bank</h3>
</div>
<div style={{border:'2px solid black', margin:'1%', padding:'6%', borderRadius:'50px'}}>
  <h3>Already added bank</h3>
</div>


{/* <Stack spacing={2} direction="row"> */}
      {/* <Button variant="text">Back</Button> */}
      <Button variant="contained" onClick={BackSixNavbarTo}>Back</Button>

      <Button variant="contained" onClick={nextEightTo}>Next</Button>
    {/* </Stack> */}

    <Stack spacing={2} direction="row"> 
          <button type="submit">
            Verify
          </button>
          </Stack>
        </form>
      </div>
    </div>


    </>
  )
}
