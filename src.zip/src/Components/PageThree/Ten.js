// import React from 'react'
import * as React from 'react';
import { styled, alpha } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import InputBase from '@mui/material/InputBase';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import { useState } from "react";


const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));


// grid
// const Item = styled(Paper)(({ theme }) => ({
//   backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
//   ...theme.typography.body2,
//   padding: theme.spacing(1),
//   textAlign: 'center',
//   color: theme.palette.text.secondary,
// }));




export default function Ten() {

// upload img
 
const [selectedImages, setSelectedImages] = useState([]);
const onSelectFile = (event) => {
  const selectedFiles = event.target.files;
  const selectedFilesArray = Array.from(selectedFiles);

  const imagesArray = selectedFilesArray.map((file) => {
    return URL.createObjectURL(file);
  });

  setSelectedImages((previousImages) => previousImages.concat(imagesArray));
};




  return (
    <> 
    <div>Ten</div>
    <div>
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
          >
            Preneurship
          </Typography>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
        </Toolbar>
      </AppBar>
    </Box>
    </div>

    {/*message  */}
    <div>
   <div>
     <h1>Messages</h1>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
   <div style={{border:'2px solid black', width:'50%'}}>
      <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
      <h3>Food</h3>
    </Stack>
    <AddCircleOutlineRoundedIcon/>
   </div>
    </div>


{/* upload img */}
<div>
<section style={{border:'2px solid black', margin:'5%', padding:'3%'}}>
    <label>
      + Add Images
      <br />
      <span>up to 10 images</span>
      <input
        type="file"
        name="images"
        onChange={onSelectFile}
        multiple
        accept="image/png , image/jpeg, image/webp"
      />
    </label>
    <br />

    {selectedImages.length > 0 &&
      (selectedImages.length > 10 ? (
        <p className="error">
          You can't upload more than 10 images! <br />
          <span>
            please delete <b> {selectedImages.length - 10} </b> of them{" "}
          </span>
        </p>
      ) : (
        <button
          className="upload-btn"
          onClick={() => {
            console.log("UPLOAD IMAGES");
          }}
        >
          UPLOAD {selectedImages.length} IMAGE
          {selectedImages.length === 1 ? "" : "S"}
        </button>
      ))}

    <div className="images">
      {selectedImages &&
        selectedImages.map((image, index) => {
          return (
            <div key={image} className="image">
              <img src={image} height="200" alt="upload" />
              <button
                onClick={() =>
                  setSelectedImages(selectedImages.filter((e) => e !== image))
                }
              >
                delete image
              </button>
              <p>{index + 1}</p>
            </div>
          );
        })}
    </div>
  </section>
</div>


    </>
  )
}
