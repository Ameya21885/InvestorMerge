// import React from 'react'
import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";


export default function Eight() {

  let navigateBack = useNavigate();
  const backSevenTo = () => {
    navigateBack("/Seven");
  };


  return (
    <> 
    <div>Eight</div>
    <div style={{border:'2px solid black', margin:'1%', padding:'2%', backgroundColor:'blueviolet'}}>
    <Stack direction="row" spacing={2}>
      <Avatar alt="Remy Sharp" src="/static/images/avatar/1.jpg" />
     
    </Stack>
    <h1>John dep</h1>
      <h4>Company Name</h4>
    </div>

<div>
<Box
      component="form"
      sx={{
        '& > :not(style)': { m: 1, width: '50ch' },
      }}
      noValidate
      autoComplete="off"
    >
      <TextField id="outlined-basic" placeholder="Company's description" />
      <TextField id="outlined-basic" placeholder="Company's valuation" />
      <TextField id="outlined-basic" placeholder="No. of employes" />
      <TextField id="outlined-basic" placeholder="Ownership list" />
      <TextField id="outlined-basic" placeholder="Company intrested category" />
     
    </Box>
</div>

<div>
<Stack spacing={2} direction="row">
      <Button variant="text" onClick={backSevenTo}>Back</Button>
    </Stack>
</div>

    </>
  )
}
