import React from 'react'
import {useState, useEffect} from "react";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';

export default function NineOne() {



  const [items, setItems]=useState([]);
  const [visible, setVisible]= useState(3);
  
  useEffect(()=>{
    fetch("https://jsonplaceholder.typicode.com/photos")
    .then((res)=>res.json())
    .then((data)=> setItems(data));
  }, []);
  
  const showMoreItems=()=>{
  setVisible((prevValue)=> prevValue +3);
  }


  return (
    <> 
    <div>NineOne</div>
    <div>
    <div className="container" >
      
      {items.slice(0,visible).map((item) =>(
        <div className="card">
         <div className="id" style={{border:'2px solid black', margin:'1%', padding:'2%'}}>
           <img src={item.thumbnailUrl} alt='logo'/>
           <span>{item.id}</span>
           <h1>John dep</h1>
         
           
           <p style={{border:'2px solid black'}}>{item.title}</p>

{/* button */}
         <div>
         <Stack spacing={2} direction="row">
    
         <Button variant="text">Like</Button> 
         <Button variant="text">Comment</Button>
     <Button variant="contained" >Connect</Button>
    
   </Stack>
   </div>
         </div>

        </div>
      ))}
<button onClick={showMoreItems}> Load more</button>
    </div>
   

    </div>
    </>
  )
}
