import React from 'react'
import "../CSS/Three.css";
import Verifyingimg from "../Image/verifyingimg.png";
// import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";


export default function Three() {

  let navigate = useNavigate();
  const FourTo = () => {
    navigate("/Four");
  };


  return (
    <>
    <div>Three</div>
    <div>
    <div>
      <div className="loader-container">
        <div class="lds-roller" style={{ display: 'inlineBlock',
    position: 'relative',
    width: '100px',
    height: '100px',
    left: '600px',
    top: '-500px'}}>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
        <img src={Verifyingimg} alt='verifyingImage' style={{marginLeft: '300px',
    marginTop: '150px'}}/>
      </div>
    </div>
    </div>
    
      <Button variant="contained" onClick={FourTo}>Next</Button>
    
    </>
  )
}
