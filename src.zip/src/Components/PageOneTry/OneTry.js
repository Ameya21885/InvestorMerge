import React from 'react'

export default function OneTry() {
  return (
    <div>OneTry</div>
  )
}
