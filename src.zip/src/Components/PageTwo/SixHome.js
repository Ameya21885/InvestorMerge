import React from 'react'
import {useState, useEffect} from "react";
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { useNavigate } from "react-router-dom";

// grid
const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));


export default function SixHome() {


  const [items, setItems]=useState([]);
  const [visible, setVisible]= useState(3);
  
  useEffect(()=>{
    fetch("https://jsonplaceholder.typicode.com/photos")
    .then((res)=>res.json())
    .then((data)=> setItems(data));
  }, []);
  
  const showMoreItems=()=>{
  setVisible((prevValue)=> prevValue +3);
  }

  let navigate = useNavigate();
  const HomeFifteenTo = () => {
    navigate("/Fifteen");
  };
  


  return (
    <> 
    <div>SixHome</div>
<div>
  <h2>Explore</h2>
</div>
    <div className="container" >
      
       {items.slice(0,visible).map((item) =>(
         <div className="card">
          <div className="id" style={{border:'2px solid black', margin:'1%', padding:'2%'}}>
           
           
           
           {/* grid */}
           <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>

      <Grid item xs={4}>
          <Item>
          <span>{item.id}</span>
          </Item>
        </Grid>
        <Grid item xs={4}>
          <Item>
          <img src={item.thumbnailUrl} alt='logo' style={{borderRadius:'100%'}}/>
          </Item>
        </Grid>
       
        <Grid item xs={4}>
          <Item>
             <h1>John dep</h1>
             </Item>
        </Grid>
        <Grid item xs={8}>
          <Item>
          <p style={{border:'2px solid black'}}>{item.title}</p>
          </Item>
        </Grid>
      </Grid>
    </Box>
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
          
            
            

{/* button */}
          <div>
          <Stack spacing={2} direction="row">
     



    <Button variant="text">Like</Button> 
    <Button variant="text">Comment</Button>
    <Button variant="contained" onClick={HomeFifteenTo}>Connect</Button>



         
         
     
     
    </Stack>
    </div>
          </div>

         </div>
       ))}
{/* <button onClick={showMoreItems} > Load more</button> */}
<Button variant="contained" onClick={showMoreItems}>Load More</Button>
     </div>
    

    </>
  )
}
