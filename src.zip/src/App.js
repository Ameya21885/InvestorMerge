//  in => investor
// inClassName

// import logo from './logo.svg';

import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

// PageOne
import One from "./Components/PageOne/One";
import Two from "./Components/PageOne/Two";
import Three from "./Components/PageOne/Three";
import Four from "./Components/PageOne/Four";
import Five from "./Components/PageOne/Five";

// PageOne Try
import OneTry from "./Components/PageOneTry/OneTry";

// PageTwo
import SixNavbar from "./Components/PageTwo/SixNavbar";

// PageThree
import Seven from "./Components/PageThree/Seven";
import Eight from "./Components/PageThree/Eight";
import Nine from "./Components/PageThree/Nine";
import NineTwo from "./Components/PageThree/NineTwo";
import Ten from "./Components/PageThree/Ten";

// Page Four
import Eleven from "./Components/PageFour/Eleven";
import Twelve from "./Components/PageFour/Twelve";
import Thirteen from "./Components/PageFour/Thirteen";
import Fourteen from "./Components/PageFour/Fourteen";

// PageFive
import Fifteen from "./Components/PageFive/Fifteen";
import SixteenGraphOne from "./Components/PageFive/SixteenGraphOne";
import SeventeenGraphTwo from "./Components/PageFive/SeventeenGraphTwo";
import Eighteen from "./Components/PageFive/Eighteen";
import Nineteen from "./Components/PageFive/Nineteen";
import Tewenty from "./Components/PageFive/Tewenty";
import TewentyOne from "./Components/PageFive/TewentyOne";
import TewentyTwo from "./Components/PageFive/TewentyTwo";
import NineOne from "./Components/PageThree/NineOne";

function App() {
  return (
    <>
      <div className="App">
        <div>
          {/* <h1>Hello World</h1> */}
          {/* <One /> */}
          {/* <Two/> */}
          {/* <Three/> */}
          {/* <Four/> */}
          {/* <Five/> */}
          {/* <SixNavbar/>  */}
          {/* <Seven/> */}
          {/* <Eight/> */}
          {/* <Nine/> */}
          {/* <NineOne/> */}
          {/* <NineTwo/> */}
          {/* <Ten/> */}
          {/* <Eleven/> */}
          {/* <Twelve/> */}
          {/* <Thirteen/> */}
          {/* <Fourteen/> */}
          {/* <Fifteen/> */}
          {/* <SixteenGraphOne/> */}
          {/* <SeventeenGraphTwo/> */}
          {/* <Eighteen/> */}
          {/* <Nineteen/> */}
          {/* <Tewenty/> */}
          {/* <TewentyOne/> */}
          {/* <TewentyTwo/> */}

          {/* ------------------------------ */}
          {/* <OneTry/> */}

          <Router>
            <Routes>
              <Route path="/" element={<One />} />
              <Route path="/two" element={<Two />} />
              <Route path="/three" element={<Three />} />
              <Route path="/four" element={<Four />} />
              <Route path="/five" element={<Five />} />
              <Route path="/SixNavbar" element={<SixNavbar />} />
              <Route path="/Seven" element={<Seven />} />
              <Route path="/Eight" element={<Eight />} />
              <Route path="/Nine" element={<Nine />} />
              <Route path="/Ten" element={<Ten />} />
              <Route path="/Eleven" element={<Eleven />} />
              <Route path="/Twelve" element={<Twelve />} />
              <Route path="/Thirteen" element={<Thirteen />} />
              <Route path="/Fourteen" element={<Fourteen />} />
              <Route path="/Fifteen" element={<Fifteen />} />
              <Route path="/SixteenGraphOne" element={<SixteenGraphOne />} />
              <Route
                path="/SeventeenGraphTwo"
                element={<SeventeenGraphTwo />}
              />
              <Route path="/Eighteen" element={<Eighteen />} />
              <Route path="/Nineteen" element={<Nineteen />} />
              <Route path="/Tewenty" element={<Tewenty />} />
              <Route path="/TewentyOne" element={<TewentyOne />} />
              <Route path="/TewentyTwo" element={<TewentyTwo />} />
            </Routes>
          </Router>
        </div>
      </div>

      {/* 


one => Two => Three => =>four =>five => SixNavbar =>





*/}
    </>
  );
}

export default App;
